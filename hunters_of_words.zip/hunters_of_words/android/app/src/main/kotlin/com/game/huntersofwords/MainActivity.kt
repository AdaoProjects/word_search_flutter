package com.game.huntersofwords

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
